import  React from 'react';

class ManagePromos extends React.Component
{

render()
{
    return(<h1>Manage Promotions</h1>);
}

}
export default ManagePromos;