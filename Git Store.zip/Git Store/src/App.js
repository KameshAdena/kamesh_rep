import React from 'react';
import ManagePromos from './managePromos.jsx';

class App extends React.Component
{

  constructor(props) {
    super(props);
    this.state = {
      showFlag: false,
    };
    this.showPromos = this.showPromos.bind(this);
  }

  showPromos() {
    this.setState({
      showFlag: true,
    });
  }
  

  render(){

    

    return(
      <div> <button type="button" hidden={this.state.showFlag} onClick={this.showPromos}>Click To See Promotions</button>
      {this.state.showFlag ? <ManagePromos /> : null}</div>
        );

  }
}


export default App;
